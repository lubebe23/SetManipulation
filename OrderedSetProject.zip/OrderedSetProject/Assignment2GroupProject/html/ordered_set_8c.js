var ordered_set_8c =
[
    [ "addElement", "ordered_set_8c.html#abbe6b7509d671667e6d964772f6f52ef", null ],
    [ "createOrderedSet", "ordered_set_8c.html#a3365b94231e96c953d86eb3eafca33d6", null ],
    [ "deleteOrderedSet", "ordered_set_8c.html#abcafde459ab7a434d2b07535372be459", null ],
    [ "printToStdout", "ordered_set_8c.html#a151f0059b66dd77c2f4ac02cdf44ee2c", null ],
    [ "removeElement", "ordered_set_8c.html#ade86a2e969e92339cae3c8e9e8ca1cad", null ],
    [ "setDifference", "ordered_set_8c.html#a1e24f91f29e93f94e88bae634761bdb3", null ],
    [ "setIntersection", "ordered_set_8c.html#aa8ab81608c427f170c086040a88794c2", null ],
    [ "setUnion", "ordered_set_8c.html#a388aa32a4084d1dd0bbead2310d6ab83", null ]
];