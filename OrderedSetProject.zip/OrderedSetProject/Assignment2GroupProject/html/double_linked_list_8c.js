var double_linked_list_8c =
[
    [ "appendNode", "double_linked_list_8c.html#a0a76fcc0a0beac6c8385987ff91f86a9", null ],
    [ "createDoubleLinkedList", "double_linked_list_8c.html#a1c2e3c1de56db470d9086db664f604a0", null ],
    [ "deleteDoubleLinkedList", "double_linked_list_8c.html#a42c4c84a3f816e5fa0de5750bacffefd", null ],
    [ "insertBefore", "double_linked_list_8c.html#af7c945cf0022b86494dc82ad49d0f2b8", null ],
    [ "printDoubleLinkedList", "double_linked_list_8c.html#aa4fb7cadd225421fe77667957ce66f77", null ],
    [ "removeNode", "double_linked_list_8c.html#a7ace5c79f0458933e9cec2617ed3eb49", null ]
];