var searchData=
[
  ['addelement_0',['addElement',['../ordered_set_8c.html#abbe6b7509d671667e6d964772f6f52ef',1,'orderedSet.c']]],
  ['appendnode_1',['appendNode',['../double_linked_list_8c.html#a0a76fcc0a0beac6c8385987ff91f86a9',1,'doubleLinkedList.c']]]
];
