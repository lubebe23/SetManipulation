var searchData=
[
  ['setdifference_0',['setDifference',['../ordered_set_8c.html#a1e24f91f29e93f94e88bae634761bdb3',1,'orderedSet.c']]],
  ['setintersection_1',['setIntersection',['../ordered_set_8c.html#aa8ab81608c427f170c086040a88794c2',1,'orderedSet.c']]],
  ['setunion_2',['setUnion',['../ordered_set_8c.html#a388aa32a4084d1dd0bbead2310d6ab83',1,'orderedSet.c']]]
];
