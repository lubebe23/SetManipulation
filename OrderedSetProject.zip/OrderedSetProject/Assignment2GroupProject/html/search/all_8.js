var searchData=
[
  ['removeelement_0',['removeElement',['../ordered_set_8c.html#ade86a2e969e92339cae3c8e9e8ca1cad',1,'orderedSet.c']]],
  ['removenode_1',['removeNode',['../double_linked_list_8c.html#a7ace5c79f0458933e9cec2617ed3eb49',1,'doubleLinkedList.c']]]
];
