var files_dup =
[
    [ "doubleLinkedList.c", "double_linked_list_8c.html", "double_linked_list_8c" ],
    [ "doubleLinkedList.h", "double_linked_list_8h_source.html", null ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "main.h", "main_8h_source.html", null ],
    [ "orderedSet.c", "ordered_set_8c.html", "ordered_set_8c" ],
    [ "orderedSet.h", "ordered_set_8h_source.html", null ]
];